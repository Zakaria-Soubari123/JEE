package com.sid.eurekadiscovery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaDiscoveryApplicationTests {

    @Test
    void contextLoads() {
    }

}
