package ord.sid.springcouldstreamskafka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringcouldStreamsKafkaApplicationTests {

    @Test
    void contextLoads() {
    }

}
