package org.sid.suppliersservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SuppliersServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
